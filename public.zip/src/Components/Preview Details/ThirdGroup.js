import React from 'react';
import { FiUpload } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

const ThirdGroup = () => {
  const navigate = useNavigate();

  return (
    <div className='flex flex-wrap items-center lg:items-end gap-[24px] lg:gap-[30px]'>
      {/* ----- 1st input ----- */}
    </div>
  );
};

export default ThirdGroup;
